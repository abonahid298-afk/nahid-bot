import { getStore } from '@netlify/blobs';
import { route } from '../../bot.js';

// Netlify Blobs হোস্টিংয়ের সাথেই ফ্রি — আলাদা ডেটাবেস লাগে না।
export default request => {
  const store = getStore('kopasamsu-bot');
  const BOT_KV = {
    get: key => store.get(key),
    put: (key, value) => store.set(key, String(value)),
  };
  return route(request, { ...process.env, BOT_KV });
};
